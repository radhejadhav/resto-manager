package com.apnacart.claud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaudServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
