package com.apnacart.claud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaudServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaudServerApplication.class, args);
	}

}
